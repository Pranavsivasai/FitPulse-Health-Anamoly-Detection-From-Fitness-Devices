import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import io


def show():
    # ── Dark / Light Mode vars ──
    dark_mode = st.session_state.get("dark_mode", True)

    if dark_mode:
        bg          = "linear-gradient(135deg, #0f0c29, #302b63, #24243e)"
        text_col    = "#e0e0e0"
        sidebar_bg  = "linear-gradient(180deg, #1a1a2e 0%, #16213e 100%)"
        sidebar_bdr = "rgba(99,179,237,0.2)"
        card_bg     = "rgba(255,255,255,0.05)"
        card_bdr    = "rgba(99,179,237,0.25)"
        upload_bg   = "rgba(255,255,255,0.04)"
        upload_bdr  = "rgba(99,179,237,0.5)"
        metric_bg   = "rgba(255,255,255,0.06)"
        metric_bdr  = "rgba(183,148,244,0.2)"
        hr_col      = "rgba(99,179,237,0.2)"
        plot_bg_global = "#1a1a2e"
    else:
        bg          = "linear-gradient(135deg, #f0f4ff, #faf0ff, #ffffff)"
        text_col    = "#1a1a2e"
        sidebar_bg  = "linear-gradient(180deg, #e8eaf6 0%, #d1c4e9 100%)"
        sidebar_bdr = "rgba(102,126,234,0.3)"
        card_bg     = "rgba(0,0,0,0.03)"
        card_bdr    = "rgba(102,126,234,0.3)"
        upload_bg   = "rgba(0,0,0,0.02)"
        upload_bdr  = "rgba(102,126,234,0.4)"
        metric_bg   = "rgba(0,0,0,0.04)"
        metric_bdr  = "rgba(118,75,162,0.25)"
        hr_col      = "rgba(102,126,234,0.25)"
        plot_bg_global = "#f8f9ff"

    st.markdown(f"""
<style>
.stApp {{
    background: {bg};
    color: {text_col};
}}
[data-testid="stSidebar"] {{
    background: {sidebar_bg};
    border-right: 1px solid {sidebar_bdr};
}}
h1, h2, h3, h4 {{
    background: linear-gradient(90deg, #63b3ed, #b794f4, #f687b3);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-weight: 800 !important;
}}
.card {{
    background: {card_bg};
    border: 1px solid {card_bdr};
    border-radius: 16px;
    padding: 20px 24px;
    margin-bottom: 16px;
    backdrop-filter: blur(10px);
    transition: transform 0.25s ease, box-shadow 0.25s ease;
}}
.card:hover {{
    transform: translateY(-4px);
    box-shadow: 0 12px 32px rgba(99,179,237,0.25);
}}
.null-pill {{
    display: inline-block;
    background: linear-gradient(90deg, #e53e3e, #c05621);
    border-radius: 999px;
    padding: 3px 14px;
    font-size: 13px;
    font-weight: 700;
    color: white;
    margin: 3px 4px;
}}
.clean-pill {{
    display: inline-block;
    background: linear-gradient(90deg, #38a169, #276749);
    border-radius: 999px;
    padding: 3px 14px;
    font-size: 13px;
    font-weight: 700;
    color: white;
    margin: 3px 4px;
}}
.stButton > button {{
    background: linear-gradient(90deg, #667eea, #764ba2);
    color: white !important;
    border: none;
    border-radius: 12px;
    padding: 10px 28px;
    font-weight: 700;
    font-size: 15px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(102,126,234,0.4);
}}
.stButton > button:hover {{
    background: linear-gradient(90deg, #764ba2, #667eea);
    transform: scale(1.04);
    box-shadow: 0 8px 25px rgba(118,75,162,0.55);
}}
[data-testid="stDataFrame"] {{
    border-radius: 12px;
    overflow: hidden;
}}
.stProgress > div > div {{ background: linear-gradient(90deg,#63b3ed,#b794f4); }}
[data-testid="stFileUploadDropzone"] {{
    background: {upload_bg} !important;
    border: 2px dashed {upload_bdr} !important;
    border-radius: 14px !important;
    transition: border-color 0.3s;
}}
[data-testid="stFileUploadDropzone"]:hover {{
    border-color: #b794f4 !important;
}}
hr {{ border-color: {hr_col}; }}
[data-testid="metric-container"] {{
    background: {metric_bg};
    border-radius: 12px;
    padding: 12px;
    border: 1px solid {metric_bdr};
}}
</style>
""", unsafe_allow_html=True)

    # ── Session State Init ──
    for key, default in [
        ("raw_df", None), ("clean_df", None),
        ("preprocessing_done", False), ("show_null_check", False),
        ("show_preview", False), ("show_eda", False),
    ]:
        if key not in st.session_state:
            st.session_state[key] = default

    # ── Sidebar pipeline steps ──
    with st.sidebar:
        st.markdown("---")
        st.markdown("**📋 Pipeline Steps**")
        st.markdown("1. 📂 Upload CSV")
        st.markdown("2. 🔍 Check Null Values")
        st.markdown("3. ⚙️ Preprocess Data")
        st.markdown("4. 👁 Preview Cleaned Data")
        st.markdown("5. 📊 Run EDA")
        st.markdown("---")
        st.markdown("<small style='color:#b794f4'>Built for Fitness & Health Tracking Datasets</small>",
                    unsafe_allow_html=True)

    # ── Header ──
    st.markdown("# 🏋️ Fitness Health Data — Pro Pipeline")
    st.markdown("Upload your fitness tracking CSV and let the pipeline preprocess, clean, and explore your data.")
    st.markdown("---")

    # ── Step 1 · Upload ──
    st.markdown("## 📂 Step 1 · Upload Dataset")
    uploaded = st.file_uploader("Drop your CSV file here", type=["csv"])

    if uploaded:
        df_raw = pd.read_csv(uploaded)
        if "last_uploaded_file" not in st.session_state or st.session_state.last_uploaded_file != uploaded.name:
            st.session_state.last_uploaded_file = uploaded.name
            st.session_state.raw_df = df_raw
            st.session_state.preprocessing_done = False
            st.session_state.clean_df = None
            st.session_state.show_null_check = False
            st.session_state.show_preview = False
            st.session_state.show_eda = False
            st.session_state.log_lines = []
            st.session_state.before_nulls = None
            st.session_state.after_nulls = None

        if st.session_state.raw_df is not None:
            _df = st.session_state.raw_df
            st.markdown(f"""
            <div class='card'>
                ✅ &nbsp;<strong>{st.session_state.last_uploaded_file}</strong> loaded successfully!
                &nbsp;&nbsp;|&nbsp;&nbsp; 🗂 <strong>{_df.shape[0]:,}</strong> rows &nbsp;×&nbsp; <strong>{_df.shape[1]}</strong> columns
            </div>
            """, unsafe_allow_html=True)

            c1, c2, c3 = st.columns(3)
            c1.metric("Rows", f"{_df.shape[0]:,}")
            c2.metric("Columns", _df.shape[1])
            c3.metric("Total Nulls", int(_df.isnull().sum().sum()))

    # ── Step 2 · Null Check ──
    if st.session_state.raw_df is not None:
        st.markdown("---")
        st.markdown("## 🔍 Step 2 · Check Null Values")

        if st.button("🔍 Check Null Values"):
            st.session_state.show_null_check = True

        if st.session_state.show_null_check:
            df = st.session_state.raw_df
            null_counts = df.isnull().sum()
            null_cols = null_counts[null_counts > 0]

            if null_cols.empty:
                st.success("🎉 No null values found in the dataset!")
            else:
                st.markdown("### Null Values Detected")
                pills_html = ""
                for col, cnt in null_cols.items():
                    pct = cnt / len(df) * 100
                    pills_html += f"<span class='null-pill'>⚠ {col}: {cnt} ({pct:.1f}%)</span>"

                st.markdown(f"<div class='card'>{pills_html}</div>", unsafe_allow_html=True)

                fig, ax = plt.subplots(figsize=(10, 3), facecolor="none")
                ax.set_facecolor("none")
                colors = plt.cm.plasma(np.linspace(0.2, 0.8, len(null_cols)))
                bars = ax.barh(null_cols.index, null_cols.values, color=colors)
                ax.set_xlabel("Null Count", color="white")
                ax.tick_params(colors="white")
                for spine in ax.spines.values():
                    spine.set_edgecolor((1, 1, 1, 0.1))
                ax.bar_label(bars, padding=4, color="white", fontsize=10)
                st.pyplot(fig, transparent=True)

    # ── Step 3 · Preprocess ──
    if st.session_state.raw_df is not None:
        st.markdown("---")
        st.markdown("## ⚙️ Step 3 · Preprocess Data")

        if st.button("⚙️ Run Preprocessing"):
            df = st.session_state.raw_df.copy()
            log_lines = []

            if "Date" in df.columns:
                df["Date"] = pd.to_datetime(df["Date"], errors="coerce", dayfirst=True)
                log_lines.append(("info", "📅 Parsed <b>Date</b> column to datetime."))

            numeric_candidates = [
                "Hours_Slept", "Water_Intake (Liters)",
                "Active_Minutes", "Heart_Rate (bpm)",
                "Steps_Taken", "Calories_Burned",
                "Stress_Level (1-10)"
            ]
            numeric_cols = [c for c in numeric_candidates if c in df.columns]

            null_before = df[numeric_cols].isnull().sum()
            null_before_cols = null_before[null_before > 0].index.tolist()

            if "User_ID" in df.columns and null_before_cols:
                df[numeric_cols] = df.groupby("User_ID")[numeric_cols].transform(
                    lambda x: x.interpolate(method="linear")
                )
                df[numeric_cols] = df.groupby("User_ID")[numeric_cols].transform(
                    lambda x: x.ffill().bfill()
                )
                cols_str = ", ".join([f"<b>{c}</b>" for c in null_before_cols])
                log_lines.append(("success", f"🔢 Interpolated (linear) + ffill/bfill null values in: {cols_str}"))
            elif null_before_cols:
                df[numeric_cols] = df[numeric_cols].interpolate(method="linear").ffill().bfill()
                cols_str = ", ".join([f"<b>{c}</b>" for c in null_before_cols])
                log_lines.append(("success", f"🔢 Interpolated null values in: {cols_str}"))

            cat_fills = {"Workout_Type": "No Workout"}
            for col, fill_val in cat_fills.items():
                if col in df.columns:
                    n = df[col].isnull().sum()
                    if n > 0:
                        df[col] = df[col].fillna(fill_val)
                        log_lines.append(("success", f"🏷 Filled <b>{n}</b> null(s) in <b>{col}</b> → '<i>{fill_val}</i>'"))

            remaining_null_cols = [c for c in df.columns if df[c].isnull().sum() > 0 and df[c].dtype in [np.float64, np.int64]]
            for col in remaining_null_cols:
                n = df[col].isnull().sum()
                df[col] = df[col].fillna(df[col].median())
                log_lines.append(("warning", f"📊 Filled remaining <b>{n}</b> null(s) in <b>{col}</b> with column median"))

            st.session_state.clean_df = df
            st.session_state.preprocessing_done = True
            st.session_state.log_lines = log_lines
            st.session_state.before_nulls = st.session_state.raw_df.isnull().sum()
            st.session_state.after_nulls = df.isnull().sum()

        if st.session_state.preprocessing_done and "log_lines" in st.session_state:
            color_map = {"info": "#63b3ed", "success": "#68d391", "warning": "#f6ad55"}
            icon_map  = {"info": "ℹ️", "success": "✅", "warning": "⚠️"}

            st.markdown("### Preprocessing Log")
            log_html = ""
            for ltype, msg in st.session_state.log_lines:
                log_html += f"""
                <div style='padding:10px 16px; margin:6px 0; border-left:4px solid {color_map[ltype]};
                            background:rgba(255,255,255,0.04); border-radius:8px; font-size:14px;'>
                    {icon_map[ltype]} &nbsp;{msg}
                </div>"""
            st.markdown(f"<div class='card'>{log_html}</div>", unsafe_allow_html=True)

            st.markdown("### Null Value Comparison")
            cc1, cc2 = st.columns(2)
            with cc1:
                st.markdown("**Before Preprocessing**")
                before_nulls = st.session_state.before_nulls
                null_df_before = before_nulls[before_nulls > 0].rename("Null Count")
                st.dataframe(null_df_before, width='stretch')
            with cc2:
                st.markdown("**After Preprocessing**")
                after_nulls = st.session_state.after_nulls
                nulls_left = after_nulls[after_nulls > 0]
                if nulls_left.empty:
                    st.success("🎉 Zero nulls remaining!")
                else:
                    st.dataframe(nulls_left.rename("Null Count"), width='stretch')

            st.markdown("### 🕐 Time Normalization Log")
            df_check = st.session_state.clean_df
            time_log_html = ""

            if "Date" in df_check.columns:
                total_rows  = len(df_check)
                valid_dates = df_check["Date"].notna().sum()
                invalid_dates = total_rows - valid_dates

                time_log_html += f"""
                <div style='padding:10px 16px; margin:6px 0; border-left:4px solid #63b3ed;
                            background:rgba(255,255,255,0.04); border-radius:8px; font-size:14px;'>
                    📅 &nbsp;<b>Date</b> column parsed → <b>{valid_dates:,}</b> valid timestamps,
                    <b style='color:#fc8181'>{invalid_dates}</b> invalid/coerced to NaT
                </div>"""

                if valid_dates > 1:
                    sample = df_check["Date"].dropna().sort_values()
                    if "User_ID" in df_check.columns:
                        sample = df_check[df_check["User_ID"] == df_check["User_ID"].iloc[0]]["Date"].dropna().sort_values()
                    diffs = sample.diff().dropna()
                    if len(diffs) > 0:
                        median_freq = diffs.median()
                        total_seconds = int(median_freq.total_seconds())
                        if total_seconds < 60:
                            freq_label = f"{total_seconds} seconds"
                        elif total_seconds < 3600:
                            freq_label = f"{total_seconds // 60} minute(s)"
                        elif total_seconds < 86400:
                            freq_label = f"{total_seconds // 3600} hour(s)"
                        else:
                            freq_label = f"{total_seconds // 86400} day(s)"

                        time_log_html += f"""
                        <div style='padding:10px 16px; margin:6px 0; border-left:4px solid #68d391;
                                    background:rgba(255,255,255,0.04); border-radius:8px; font-size:14px;'>
                            📊 &nbsp;Detected data frequency: <b>~{freq_label}</b> per record
                            (median interval across sample user)
                        </div>"""

                date_min = df_check["Date"].min()
                date_max = df_check["Date"].max()
                time_log_html += f"""
                <div style='padding:10px 16px; margin:6px 0; border-left:4px solid #b794f4;
                            background:rgba(255,255,255,0.04); border-radius:8px; font-size:14px;'>
                    🗓 &nbsp;Date range: <b>{date_min.date()}</b> → <b>{date_max.date()}</b>
                    &nbsp;|&nbsp; Span: <b>{(date_max - date_min).days} days</b>
                </div>"""

                time_log_html += """
                <div style='padding:10px 16px; margin:6px 0; border-left:4px solid #f6ad55;
                            background:rgba(255,255,255,0.04); border-radius:8px; font-size:14px;'>
                    ⚠️ &nbsp;Timezone: timestamps stored as <b>local/naive</b>.
                    UTC normalization skipped — dataset does not carry timezone info.
                </div>"""
            else:
                time_log_html += """
                <div style='padding:10px 16px; margin:6px 0; border-left:4px solid #fc8181;
                            background:rgba(255,255,255,0.04); border-radius:8px; font-size:14px;'>
                    ❌ &nbsp;No <b>Date</b> column found in dataset — time normalization skipped.
                </div>"""

            st.markdown(f"<div class='card'>{time_log_html}</div>", unsafe_allow_html=True)

    # ── Step 4 · Preview ──
    if st.session_state.preprocessing_done and st.session_state.clean_df is not None:
        st.markdown("---")
        st.markdown("## 👁 Step 4 · Preview Cleaned Dataset")

        if st.button("👁 Preview Cleaned Data"):
            st.session_state.show_preview = True

        if st.session_state.get("show_preview", False):
            df_clean = st.session_state.clean_df
            st.dataframe(df_clean.head(50), width='stretch')
            csv_bytes = df_clean.to_csv(index=False).encode()
            st.download_button(
                label="⬇️ Download Cleaned CSV",
                data=csv_bytes,
                file_name="cleaned_fitness_data.csv",
                mime="text/csv",
            )

    # ── Step 5 · EDA ──
    if st.session_state.preprocessing_done and st.session_state.clean_df is not None:
        st.markdown("---")
        st.markdown("## 📊 Step 5 · Exploratory Data Analysis")

        if st.button("📊 Run Full EDA"):
            st.session_state.show_eda = True

        if st.session_state.get("show_eda", False):
            df = st.session_state.clean_df

            numeric_cols = [c for c in [
                "Steps_Taken", "Calories_Burned", "Hours_Slept",
                "Active_Minutes", "Heart_Rate (bpm)", "Stress_Level (1-10)"
            ] if c in df.columns]

            plot_bg    = plot_bg_global
            text_color = text_col

            def style_ax(ax):
                ax.set_facecolor(plot_bg)
                ax.tick_params(colors=text_color)
                ax.xaxis.label.set_color(text_color)
                ax.yaxis.label.set_color(text_color)
                ax.title.set_color(text_color)
                for spine in ax.spines.values():
                    spine.set_edgecolor((1, 1, 1, 0.15) if dark_mode else (0, 0, 0, 0.15))

            palette = ["#63b3ed", "#b794f4", "#f687b3", "#68d391", "#f6ad55", "#fc8181"]

            st.markdown("### 📈 Distribution of Numeric Features")
            fig, axes = plt.subplots(3, 2, figsize=(14, 10), facecolor=plot_bg)
            axes = axes.flatten()
            for i, col in enumerate(numeric_cols[:6]):
                sns.histplot(df[col], kde=True, ax=axes[i], color=palette[i], alpha=0.8)
                axes[i].set_title(f"Distribution of {col}")
                style_ax(axes[i])
            plt.tight_layout()
            st.pyplot(fig, transparent=True)
            plt.close(fig)

            st.markdown("### 📦 Outlier Detection (Boxplots)")
            fig, axes = plt.subplots(3, 2, figsize=(14, 10), facecolor=plot_bg)
            axes = axes.flatten()
            for i, col in enumerate(numeric_cols[:6]):
                sns.boxplot(x=df[col], ax=axes[i], color=palette[i])
                axes[i].set_title(f"Boxplot of {col}")
                style_ax(axes[i])
            plt.tight_layout()
            st.pyplot(fig, transparent=True)
            plt.close(fig)

            st.markdown("### 🔥 Correlation Heatmap")
            corr = df[numeric_cols].corr()
            fig, ax = plt.subplots(figsize=(20, 5), facecolor=plot_bg)
            ax.set_facecolor(plot_bg)
            sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f", ax=ax,
                        linewidths=0.5, linecolor="#1a1a2e", annot_kws={"color": "white" if dark_mode else "black"})
            ax.tick_params(colors=text_color)
            plt.title("Correlation Heatmap", color=text_color)
            st.pyplot(fig, transparent=True)
            plt.close(fig)

            if "Date" in df.columns and "User_ID" in df.columns and "Heart_Rate (bpm)" in df.columns:
                st.markdown("### 📅 Heart Rate Time-Series (Sample User)")
                user_id   = df["User_ID"].iloc[0]
                user_data = df[df["User_ID"] == user_id].sort_values("Date")
                fig, ax   = plt.subplots(figsize=(12, 4), facecolor=plot_bg)
                ax.set_facecolor(plot_bg)
                ax.plot(user_data["Date"], user_data["Heart_Rate (bpm)"], color="#f687b3", linewidth=2)
                ax.fill_between(user_data["Date"], user_data["Heart_Rate (bpm)"], alpha=0.2, color="#f687b3")
                ax.set_title(f"Heart Rate Trend — User {user_id}", color=text_color)
                ax.tick_params(colors=text_color, axis="both")
                plt.xticks(rotation=45)
                style_ax(ax)
                st.pyplot(fig, transparent=True)
                plt.close(fig)

            if "Workout_Type" in df.columns:
                st.markdown("### 🥧 Workout Type Distribution")
                wc  = df["Workout_Type"].value_counts()
                fig, ax = plt.subplots(figsize=(3, 3), facecolor=plot_bg)
                ax.set_facecolor(plot_bg)
                wedge_colors = plt.cm.plasma(np.linspace(0.1, 0.9, len(wc)))
                wedges, texts, autotexts = ax.pie(
                    wc, labels=wc.index, autopct='%1.1f%%',
                    startangle=90, colors=wedge_colors,
                    wedgeprops=dict(edgecolor='#1a1a2e', linewidth=2)
                )
                for t in texts + autotexts:
                    t.set_color(text_color)
                ax.set_title("Workout Type Distribution", color=text_color)
                col1, col2, col3 = st.columns([1, 2, 1])
                with col2:
                    st.pyplot(fig, transparent=True)
                plt.close(fig)

            if "User_ID" in df.columns:
                st.markdown("### 👥 User-Level Average Summary")
                user_summary = df.groupby("User_ID")[numeric_cols].mean().round(2)
                st.dataframe(user_summary.head(20), width='stretch')

            st.success("✅ EDA complete!")

    # ── Footer ──
    st.markdown("---")
    st.markdown("""
<div style='text-align:center; color:rgba(255,255,255,0.3); font-size:13px; padding:10px 0'>
    💪 Fitness Data Pro &nbsp;|&nbsp; Built with Streamlit &nbsp;|&nbsp; Professional EDA Pipeline
</div>
""", unsafe_allow_html=True)
