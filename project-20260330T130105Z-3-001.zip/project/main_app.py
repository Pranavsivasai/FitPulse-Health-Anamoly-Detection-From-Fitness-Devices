import streamlit as st

# ── Page config (only one set_page_config allowed per app) ────────────────────
st.set_page_config(
    page_title="FitPulse · Analytics Suite",
    page_icon="🏃",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Global session state ───────────────────────────────────────────────────────
if "dark_mode" not in st.session_state:
    st.session_state.dark_mode = True

dark = st.session_state.dark_mode

# Theme colours used for the shared sidebar header
ACCENT  = "#63b3ed" if dark else "#3182ce"
ACCENT2 = "#f687b3" if dark else "#d53f8c"
MUTED   = "#94a3b8" if dark else "#4a5568"
TEXT    = "#e2e8f0" if dark else "#1a202c"
CARD_BOR = "rgba(99,179,237,0.2)" if dark else "rgba(66,153,225,0.25)"
SB_BG   = "rgba(10,14,26,0.97)"  if dark else "rgba(240,244,255,0.97)"

# ── Shared sidebar ─────────────────────────────────────────────────────────────
with st.sidebar:
    # Brand header
    st.markdown(f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=JetBrains+Mono:wght@400;500&family=Inter:wght@400;500;600&display=swap');
[data-testid="stSidebar"] {{
    background: {SB_BG} !important;
    border-right: 1px solid {CARD_BOR};
}}
[data-testid="stSidebar"] * {{ color: {TEXT} !important; font-family: 'Inter', sans-serif; }}
</style>
<div style="padding: 0.8rem 0 1.2rem">
  <div style="font-family:'Syne',sans-serif;font-size:1.35rem;font-weight:800;
              color:{ACCENT};letter-spacing:-0.01em">
    🏃 FitPulse Suite
  </div>
  <div style="font-size:0.7rem;color:{MUTED};font-family:'JetBrains Mono',monospace;
              margin-top:0.25rem;letter-spacing:0.04em">
    FITNESS ANALYTICS PLATFORM
  </div>
</div>
""", unsafe_allow_html=True)

    # Dark mode toggle
    new_dark = st.toggle("🌙 Dark Mode", value=st.session_state.dark_mode)
    if new_dark != st.session_state.dark_mode:
        st.session_state.dark_mode = new_dark
        st.rerun()

    st.markdown(f'<hr style="border-color:{CARD_BOR};margin:1rem 0">', unsafe_allow_html=True)

    # ── Milestone selector ─────────────────────────────────────────────────────
    st.markdown(f"""
<div style="font-size:0.7rem;color:{MUTED};font-family:'JetBrains Mono',monospace;
            letter-spacing:0.06em;margin-bottom:0.5rem">
  SELECT MILESTONE
</div>
""", unsafe_allow_html=True)

    milestone = st.selectbox(
        label="milestone",
        options=[
            "🔧  Milestone 1 — Preprocessing",
            "🧬  Milestone 2 — Pattern Extraction",
        ],
        index=0,
        label_visibility="collapsed",
    )

    st.markdown(f'<hr style="border-color:{CARD_BOR};margin:1rem 0">', unsafe_allow_html=True)

# ── Route to selected milestone ────────────────────────────────────────────────
if "Preprocessing" in milestone:
    from preprocessing_page import show as show_preprocessing
    show_preprocessing()
else:
    from pattern_extraction_page import show as show_pattern_extraction
    show_pattern_extraction()
